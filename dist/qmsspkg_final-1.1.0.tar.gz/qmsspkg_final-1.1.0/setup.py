# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['qmsspkg_final']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'qmsspkg-final',
    'version': '1.1.0',
    'description': 'Python package that scrap API',
    'long_description': '# qmsspkg_final\n\nPython package that scrap SportsRadar API\n\n## Installation\n\n```bash\n$ pip install qmsspkg_final\n```\n\n## Usage\n\nGet the MLB Teams that has the most top ranked players in a given stats\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`qmsspkg_final` was created by Teng-Shao Lu. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`qmsspkg_final` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n',
    'author': 'Teng-Shao Lu',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
