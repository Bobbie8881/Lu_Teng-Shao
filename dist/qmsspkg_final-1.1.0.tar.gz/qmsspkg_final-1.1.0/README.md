# qmsspkg_final

Python package that scrap SportsRadar API

## Installation

```bash
$ pip install qmsspkg_final
```

## Usage

Get the MLB Teams that has the most top ranked players in a given stats

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`qmsspkg_final` was created by Teng-Shao Lu. It is licensed under the terms of the MIT license.

## Credits

`qmsspkg_final` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
